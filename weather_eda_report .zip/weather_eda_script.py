
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Загрузка данных
df = pd.read_csv("weather_by_city.csv")
df["date"] = pd.to_datetime(df["date"])

# Сводная статистика
summary_stats = df.describe(include="all")
summary_stats.to_csv("summary_statistics.csv")

# Группировка по городам
city_summary = df.groupby("city")[["avg_temp_c", "precipitation_mm"]].mean().reset_index()
city_summary.to_csv("city_summary.csv", index=False)

# График температуры по датам
plt.figure(figsize=(10, 5))
sns.lineplot(data=df, x="date", y="avg_temp_c", hue="city")
plt.title("Average Temperature Over Time by City")
plt.xlabel("Date")
plt.ylabel("Avg Temperature (°C)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("avg_temp_over_time.png")
plt.close()

# График осадков по датам
plt.figure(figsize=(10, 5))
sns.lineplot(data=df, x="date", y="precipitation_mm", hue="city")
plt.title("Precipitation Over Time by City")
plt.xlabel("Date")
plt.ylabel("Precipitation (mm)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("precipitation_over_time.png")
plt.close()
